import app


application = app.configured_app()