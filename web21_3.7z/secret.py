secret_key = 'dadasd'
database_password = 'test'
test_mail = 'bao.job@outlook.com'
admin_mail = 'admin@kybmig.cc'