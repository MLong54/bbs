secret_key = 'dasdasd'
mysql_password = 'test'